

def printer(toprint):
	print(toprint)


def holllllllllllllllaaaaaa(toprint):
	print(toprint)